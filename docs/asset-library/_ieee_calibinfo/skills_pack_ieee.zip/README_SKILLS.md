# skills_pack_ieee — 给 agent 的技能包（calibinfo / IEEE 论文）

本包把一个科研项目（线性化逆问题的模式解析标定置信度 → IEEE 论文）所需的本地技能资产
按「可逐个上传的 self-contained skill」重新组织。**每个 `NN_*` 目录 = 一个可上传的 skill**
（根 `SKILL.md` 是入口；`modules/` 是被合并的技能；`resources/` 是该 skill 运行时内聚的脚本/配方，已自包含，不再依赖仓库其它位置）。

## 上传方式
- 每个 skill = 一个目录，整目录上传到 agent 的 skills 目录即可（保留 `NN_*` 目录名与内部结构）。
- 有依赖编排的（写作用 figure、编译、审计）按下列顺序交错使用，但每个 skill 本身独立可用。

## Skill 清单

| 目录 | 名称 | 合并自（原资产） | 内聚资源 | 用途 |
|---|---|---|---|---|
| `00_ieee_templates` | IEEE 官方模板 | CTAN 下载 | IEEEtran.cls(V1.8b)/IEEEtran.bst/bare_adv.tex/HOWTO | IEEE 双栏排版 + 数字引用 + 样例 |
| `01_en_manuscript_writing` | 英文论文写作 | paper-write-nature(+paper-write, paper-plan) | writing_rules, error_prevention | hourglass 结构、出版级英文、逐节 LaTeX |
| `02_figure_generation` | 出版级图表 | nature-figure(+paper-figure) | figure_style_guide, figure_recipes_basic/advanced/competition, plot_utils/get_recipe/recipe_audit, fig_*_check, figure_check | 数据图生成与统一风格（science/IEEE 配色） |
| `03_schematic_diagrams` | 示意图/流程图 | paper-figure-html(+paper-figure-drawio, mermaid-diagram) | drawio/tikz 规则+检查, html tpl+themes | overview 示意图、方法/架构/数据流图、TikZ 化 |
| `04_research_claim_audit` | 结果→声明审计 | result-to-claim(+analyze-results, ablation-planner) | facts_audit, claim_code_check, cross_problem_check, paper_claim_check, logic_audit, bib_authenticity_check, data_profile, error_prevention | 判断结果支撑哪些声明、可复现/防伪审计 |
| `05_literature_novelty` | 文献与查新 | literature-review(+arxiv, novelty-check) | bib_authenticity_check | Related Work 检索/撰写、非引真实性、novelty 自证 |
| `06_latex_compile_en` | 英文 LaTeX 编译 | paper-compile | compile_check.sh, compile_utils.sh | pdflatex 编译 → PDF，宏包/公式校验 |
| `07_quality_review` | 学术质量审查 | quality-check | — | 字数/结构/引用/格式审查报告 |
| `08_editor_agent` | 论文编辑器代理 | editor-agent | — | 读写/跑代码/编译/导出 交互 |
| `09_rebuttal` | 审稿回复 | rebuttal | — | 解析外审、安全起草 rebuttal 并管理多轮 |

## 推荐工作流（供参考，非强制）
文献(05) → 查新(05) → 定大纲(01`modules/paper-plan`) → 跑结果至声明(04) →
写正文(01) → 出图(02) → 示意图(03) → 编译(06) → 质量审查(07) → 编辑器精修(08) → 投稿(00 IEEE 模板) → 审稿回复(09)。

## 关于依赖的说明
- `01/02/03/04/05` 中并入的 `paper-*`/`nature-*`/审计脚本对 `shared-scripts` 的引用，已通过 `resources/`
  目录内聚进各自 skill，**解压后不依赖本项目其它路径**；个别 SKILL.md 内的绝对引用路径，上传后按 agent
  环境将 `resources/` 映射到对应工作目录即可。
- `00_ieee_templates` 用 CTAN 官方 IEEEtran；需本地装有 pdflatex/xelatex（06 技能负责编译）。